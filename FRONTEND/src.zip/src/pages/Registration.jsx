const Registration = () => {
  return <h2>Project & Agent Registration</h2>;
};

export default Registration;