const Registered = () => {
  return <h2>Registered Projects & Agents</h2>;
};

export default Registered;