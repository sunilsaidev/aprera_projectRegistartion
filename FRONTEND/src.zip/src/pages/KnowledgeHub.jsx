const KnowledgeHub = () => {
  return <h2>Knowledge Hub</h2>;
};

export default KnowledgeHub;