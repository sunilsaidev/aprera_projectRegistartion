const About = () => {
  return (
    <>
      <h2>About AP RERA</h2>
      <p>
        Andhra Pradesh Real Estate Regulatory Authority regulates real estate
        sector and protects home buyers.
      </p>
    </>
  );
};

export default About;