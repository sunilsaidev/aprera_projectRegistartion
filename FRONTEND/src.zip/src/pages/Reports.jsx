const Reports = () => {
  return <h2>Reports Section</h2>;
};

export default Reports;