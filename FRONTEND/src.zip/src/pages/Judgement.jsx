const Judgements = () => {
  return <h2>Judgements & Orders</h2>;
};

export default Judgements;