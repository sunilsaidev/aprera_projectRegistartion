const Notifications = () => {
  return <h2>Notifications & Circulars</h2>;
};

export default Notifications;