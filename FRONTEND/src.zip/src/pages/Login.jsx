const Login = () => {
  return <h2>Login Page</h2>;
};

export default Login;